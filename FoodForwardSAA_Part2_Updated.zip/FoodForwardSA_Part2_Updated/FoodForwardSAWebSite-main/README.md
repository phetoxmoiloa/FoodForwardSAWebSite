# FoodForwardSAWebSite
This project is a concept website for **FoodForward SA**, a real South African NPO established in 2009 that recovers quality surplus food from farmers, manufacturers and retailers and redistributes it to a vetted network of beneficiary organizations across all nine provinces.


## Part 2 update
The `FoodForwardSA_WEDE5020/foodforwardsa` folder contains the updated Part 2 CSS and responsive-design implementation. See its README for the change log and testing notes.
